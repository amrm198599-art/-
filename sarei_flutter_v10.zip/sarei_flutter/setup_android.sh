#!/bin/bash
# شغّله مرة واحدة من داخل مجلد المشروع: bash setup_android.sh
set -e
mkdir -p /tmp/sarei_keep
cp -r android/app/build.gradle.kts android/app/src/main/AndroidManifest.xml android/app/src/main/kotlin /tmp/sarei_keep/
flutter create --project-name sarei --org com.sarei --platforms android .
rm -rf android/app/src/main/kotlin
cp -r /tmp/sarei_keep/kotlin android/app/src/main/kotlin
cp /tmp/sarei_keep/build.gradle.kts android/app/build.gradle.kts
cp /tmp/sarei_keep/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
flutter pub get
dart run flutter_launcher_icons
echo "جاهز. شغّل flutter run"
