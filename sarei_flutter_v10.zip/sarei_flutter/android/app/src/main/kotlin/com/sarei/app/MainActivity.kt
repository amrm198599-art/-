package com.sarei.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
