#!/bin/bash
# يحمّل ملف اللغة العربية (ويحدّث الإنجليزية) إلى assets/tessdata
set -e
cd "$(dirname "$0")/assets/tessdata"
B=https://github.com/tesseract-ocr/tessdata_fast/raw/main
curl -L -o ara.traineddata $B/ara.traineddata
ls -l
