import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as sf;

class SignPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const SignPage({super.key, required this.onDone});
  @override
  State<SignPage> createState() => _SignPageState();
}

class _SignPageState extends State<SignPage> {
  Uint8List? pdf;
  String? name;
  final strokes = <List<Offset>>[];
  Size padSize = const Size(300, 170);
  int align = 0; // 0 يمين، 1 وسط، 2 يسار
  final pageCtl = TextEditingController(text: '1');
  final pass = TextEditingController();
  bool busy = false;
  Uint8List? result;
  String? error;

  @override
  void dispose() {
    pageCtl.dispose();
    pass.dispose();
    super.dispose();
  }

  Future<void> pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], withData: true);
    if (r == null || r.files.first.bytes == null) return;
    setState(() { pdf = r.files.first.bytes; name = r.files.first.name; result = null; error = null; });
  }

  Future<Uint8List> _sigPng() async {
    final rec = ui.PictureRecorder();
    final c = Canvas(rec)..scale(2);
    final p = Paint()..color = Colors.black..strokeWidth = 3..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    for (final s in strokes) {
      if (s.length == 1) { c.drawPoints(ui.PointMode.points, s, p); continue; }
      final path = Path()..moveTo(s.first.dx, s.first.dy);
      for (final o in s.skip(1)) { path.lineTo(o.dx, o.dy); }
      c.drawPath(path, p);
    }
    final im = await rec.endRecording().toImage((padSize.width * 2).ceil(), (padSize.height * 2).ceil());
    return (await im.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }

  Future<void> run() async {
    final wantSign = strokes.isNotEmpty, wantPass = pass.text.isNotEmpty;
    if (!wantSign && !wantPass) { setState(() => error = 'ارسم توقيعًا أو اكتب كلمة سر (أو الاثنين).'); return; }
    setState(() { busy = true; error = null; result = null; });
    try {
      final doc = sf.PdfDocument(inputBytes: pdf);
      if (wantSign) {
        final idx = ((int.tryParse(pageCtl.text) ?? 1) - 1).clamp(0, doc.pages.count - 1);
        final page = doc.pages[idx];
        final size = page.getClientSize();
        final w = size.width * 0.35, h = w * padSize.height / padSize.width;
        final x = align == 0 ? size.width - w - 30 : align == 1 ? (size.width - w) / 2 : 30.0;
        page.graphics.drawImage(sf.PdfBitmap(await _sigPng()), Rect.fromLTWH(x, size.height - h - 40, w, h));
      }
      if (wantPass) {
        doc.security.algorithm = sf.PdfEncryptionAlgorithm.aesx256Bit;
        doc.security.userPassword = pass.text;
      }
      result = Uint8List.fromList(await doc.save());
      doc.dispose();
      await widget.onDone();
    } catch (_) {
      error = 'تعذّرت المعالجة. قد يكون الملف محميًا بكلمة سر أو تالفًا.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('توقيع وتأمين PDF')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(60)),
            onPressed: pick, icon: const Icon(Icons.upload_file), label: Text(name ?? 'اختر ملف PDF من الهاتف')),
          if (pdf != null) ...[
            const SizedBox(height: 18),
            Row(children: [
              const Text('التوقيع بخط اليد', style: TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              TextButton(onPressed: () => setState(strokes.clear), child: const Text('مسح')),
            ]),
            Container(
              height: 170,
              decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.black26), borderRadius: BorderRadius.circular(14)),
              child: LayoutBuilder(builder: (c, k) {
                padSize = Size(k.maxWidth, k.maxHeight);
                return GestureDetector(
                  onPanStart: (d) => setState(() => strokes.add([d.localPosition])),
                  onPanUpdate: (d) => setState(() => strokes.last.add(d.localPosition)),
                  child: ClipRRect(borderRadius: BorderRadius.circular(14), child: CustomPaint(painter: _SigPainter(strokes), size: Size.infinite)),
                );
              }),
            ),
            const SizedBox(height: 12),
            Row(children: [
              SizedBox(width: 90, child: TextField(controller: pageCtl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الصفحة', border: OutlineInputBorder()))),
              const SizedBox(width: 12),
              Expanded(child: SegmentedButton<int>(
                segments: const [ButtonSegment(value: 0, label: Text('يمين')), ButtonSegment(value: 1, label: Text('وسط')), ButtonSegment(value: 2, label: Text('يسار'))],
                selected: {align}, onSelectionChanged: (s) => setState(() => align = s.first))),
            ]),
            const SizedBox(height: 14),
            TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة السر (اختيارية)', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder())),
            const SizedBox(height: 6),
            const Text('احتفظ بكلمة السر؛ لا يمكننا استرجاعها إن نسيتها.', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 14),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE08A22), minimumSize: const Size.fromHeight(52)),
              onPressed: busy ? null : run, child: Text(busy ? 'جارٍ التنفيذ...' : 'ابدأ المعالجة السريعة')),
          ],
          if (error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          if (result != null) ...[
            const SizedBox(height: 16),
            Card(color: Theme.of(context).colorScheme.primaryContainer, child: const Padding(padding: EdgeInsets.all(16), child: Text('تم تجهيز الملف بنجاح', style: TextStyle(fontWeight: FontWeight.bold)))),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => Printing.sharePdf(bytes: result!, filename: 'sarei_signed.pdf'), icon: const Icon(Icons.share), label: const Text('مشاركة'))),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(
                onPressed: () async {
                  final p = await FilePicker.platform.saveFile(fileName: 'sarei_signed.pdf', bytes: result, type: FileType.custom, allowedExtensions: ['pdf']);
                  if (p != null && context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الملف')));
                },
                icon: const Icon(Icons.save_alt), label: const Text('حفظ'))),
            ]),
          ],
        ]),
      );
}

class _SigPainter extends CustomPainter {
  final List<List<Offset>> strokes;
  _SigPainter(this.strokes);
  @override
  void paint(Canvas c, Size s) {
    final p = Paint()..color = Colors.black..strokeWidth = 3..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
    for (final st in strokes) {
      if (st.length == 1) { c.drawPoints(ui.PointMode.points, st, p); continue; }
      final path = Path()..moveTo(st.first.dx, st.first.dy);
      for (final o in st.skip(1)) { path.lineTo(o.dx, o.dy); }
      c.drawPath(path, p);
    }
  }
  @override
  bool shouldRepaint(_SigPainter old) => true;
}
