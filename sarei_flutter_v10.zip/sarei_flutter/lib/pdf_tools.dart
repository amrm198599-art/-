import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

enum PdfMode { merge, compress }

class _Picked {
  final String name;
  final Uint8List bytes;
  _Picked(this.name, this.bytes);
}

Uint8List _pngToJpg(List<dynamic> a) {
  final decoded = img.decodePng(a[0] as Uint8List);
  if (decoded == null) throw Exception('decode');
  return Uint8List.fromList(img.encodeJpg(decoded, quality: a[1] as int));
}

/// يعيد بناء ملفات PDF محليًا: كل صفحة تُحوَّل لصورة JPEG ثم تُجمع في ملف جديد.
Future<Uint8List> rebuildPdf(List<Uint8List> pdfs,
    {required double dpi, required int quality, ValueChanged<int>? onPage, bool Function()? cancelled}) async {
  final doc = pw.Document();
  var n = 0;
  for (final bytes in pdfs) {
    await for (final page in Printing.raster(bytes, dpi: dpi)) {
      if (cancelled?.call() ?? false) throw const FormatException('cancelled');
      final png = await page.toPng();
      final jpg = await compute(_pngToJpg, [png, quality]);
      final w = page.width * 72 / dpi, h = page.height * 72 / dpi;
      doc.addPage(pw.Page(
        pageFormat: PdfPageFormat(w, h),
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pw.MemoryImage(jpg), fit: pw.BoxFit.fill),
      ));
      onPage?.call(++n);
    }
  }
  if (n == 0) throw Exception('empty');
  return doc.save();
}

String fmtSize(int b) => b >= 1048576
    ? '${(b / 1048576).toStringAsFixed(2)} MB'
    : '${(b / 1024).toStringAsFixed(0)} KB';

class PdfToolPage extends StatefulWidget {
  final PdfMode mode;
  final Future<void> Function() onDone;
  const PdfToolPage({super.key, required this.mode, required this.onDone});
  @override
  State<PdfToolPage> createState() => _PdfToolPageState();
}

class _PdfToolPageState extends State<PdfToolPage> {
  final files = <_Picked>[];
  bool busy = false, cancel = false;
  int pagesDone = 0, level = 1;
  Uint8List? result;
  String? message;

  bool get merge => widget.mode == PdfMode.merge;
  static const levels = [(100.0, 55, 'قوي'), (130.0, 70, 'متوسط'), (170.0, 85, 'خفيف')];

  int get originalSize => files.fold(0, (s, f) => s + f.bytes.length);

  Future<void> pick() async {
    final r = await FilePicker.platform.pickFiles(
        type: FileType.custom, allowedExtensions: ['pdf'], allowMultiple: merge, withData: true);
    if (r == null) return;
    setState(() {
      files
        ..clear()
        ..addAll(r.files.where((f) => f.bytes != null).map((f) => _Picked(f.name, f.bytes!)));
      result = null;
      message = null;
    });
  }

  Future<void> run() async {
    cancel = false;
    setState(() { busy = true; pagesDone = 0; result = null; message = null; });
    try {
      final l = levels[level];
      final out = await rebuildPdf(files.map((f) => f.bytes).toList(),
          dpi: merge ? 150 : l.$1, quality: merge ? 80 : l.$2,
          onPage: (n) { if (mounted) setState(() => pagesDone = n); }, cancelled: () => cancel);
      if (!merge && out.length >= originalSize) {
        message = 'الملف الأصلي مضغوط بالفعل، ولم ينقص الحجم. جرّب مستوى ضغط أقوى.';
      } else {
        result = out;
        await widget.onDone();
      }
    } on FormatException {
      message = 'تم إلغاء العملية.';
    } catch (_) {
      message = 'تعذّرت معالجة الملف. قد يكون محميًا بكلمة سر أو تالفًا.';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> save() async {
    final name = merge ? 'sarei_merged.pdf' : 'sarei_compressed.pdf';
    final p = await FilePicker.platform.saveFile(
        dialogTitle: 'حفظ الملف', fileName: name, bytes: result,
        type: FileType.custom, allowedExtensions: ['pdf']);
    if (p != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ الملف')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(merge ? 'دمج PDF' : 'ضغط PDF')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        FilledButton.icon(
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(64)),
          onPressed: busy ? null : pick,
          icon: const Icon(Icons.upload_file_rounded),
          label: Text(merge ? 'اختر ملفات PDF من الهاتف' : 'اختر ملف PDF من الهاتف'),
        ),
        const SizedBox(height: 16),
        for (final f in files)
          Card(child: ListTile(
            leading: const Icon(Icons.picture_as_pdf_rounded, color: Color(0xFFE35B54)),
            title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(fmtSize(f.bytes.length)),
          )),
        if (files.isNotEmpty && !merge) ...[
          const SizedBox(height: 8),
          const Text('مستوى الضغط'),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: [for (var i = 0; i < 3; i++) ButtonSegment(value: i, label: Text(levels[i].$3))],
            selected: {level},
            onSelectionChanged: busy ? null : (s) => setState(() => level = s.first),
          ),
        ],
        if (files.length > 1 && merge)
          const Padding(padding: EdgeInsets.only(top: 4), child: Text('يتم الدمج بترتيب الاختيار.')),
        const SizedBox(height: 16),
        FilledButton(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE08A22), minimumSize: const Size.fromHeight(52)),
          onPressed: busy || files.isEmpty || (merge && files.length < 2) ? null : run,
          child: const Text('ابدأ المعالجة السريعة'),
        ),
        if (busy) ...[
          const SizedBox(height: 20),
          const LinearProgressIndicator(),
          const SizedBox(height: 8),
          Center(child: Text('تمت معالجة $pagesDone صفحة...')),
          TextButton(onPressed: () => cancel = true, child: const Text('إلغاء')),
        ],
        if (message != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(message!, style: TextStyle(color: cs.error))),
        if (result != null) ...[
          const SizedBox(height: 20),
          Card(color: cs.primaryContainer, child: Padding(padding: const EdgeInsets.all(16), child: Text(
            merge
                ? 'تم الدمج. الحجم النهائي: ${fmtSize(result!.length)}'
                : 'تم تقليل الحجم بنسبة ${((1 - result!.length / originalSize) * 100).round()}%\n${fmtSize(originalSize)} ← ${fmtSize(result!.length)}',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)))),
          const SizedBox(height: 8),
          const Text('ملاحظة: الصفحات في الملف الناتج تصبح صورًا، فلا يمكن تحديد النص منها.', style: TextStyle(fontSize: 12)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton.icon(
              onPressed: () => Printing.sharePdf(bytes: result!, filename: merge ? 'sarei_merged.pdf' : 'sarei_compressed.pdf'),
              icon: const Icon(Icons.share), label: const Text('مشاركة الملف'))),
            const SizedBox(width: 10),
            Expanded(child: FilledButton.icon(onPressed: save, icon: const Icon(Icons.save_alt), label: const Text('حفظ في الجهاز'))),
          ]),
        ],
      ]),
    );
  }
}

/// تحويل صفحات PDF إلى صور PNG تُحفظ في معرض الصور (ألبوم Sarei) بدون صلاحيات.
class PdfToImagesPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const PdfToImagesPage({super.key, required this.onDone});
  @override
  State<PdfToImagesPage> createState() => _PdfToImagesPageState();
}

class _PdfToImagesPageState extends State<PdfToImagesPage> {
  String? name;
  Uint8List? bytes;
  bool busy = false;
  int done = 0;
  String? msg;

  Future<void> pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], withData: true);
    if (r == null || r.files.first.bytes == null) return;
    setState(() { name = r.files.first.name; bytes = r.files.first.bytes; msg = null; done = 0; });
  }

  Future<void> run() async {
    setState(() { busy = true; done = 0; msg = null; });
    try {
      final base = name!.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '');
      await for (final page in Printing.raster(bytes!, dpi: 150)) {
        await Gal.putImageBytes(await page.toPng(), album: 'Sarei', name: '${base}_${++done}');
        if (mounted) setState(() {});
      }
      msg = done == 0 ? 'الملف لا يحتوي صفحات.' : 'تم حفظ $done صورة في ألبوم Sarei بالمعرض.';
      if (done > 0) await widget.onDone();
    } catch (_) {
      msg = 'تعذّر التحويل. قد يكون الملف محميًا بكلمة سر أو تالفًا.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('تحويل PDF إلى صور')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(60)),
            onPressed: busy ? null : pick, icon: const Icon(Icons.upload_file), label: Text(name ?? 'اختر ملف PDF من الهاتف')),
          const SizedBox(height: 14),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE08A22), minimumSize: const Size.fromHeight(52)),
            onPressed: busy || bytes == null ? null : run, child: const Text('ابدأ المعالجة السريعة')),
          if (busy) ...[const SizedBox(height: 16), const LinearProgressIndicator(), const SizedBox(height: 8), Center(child: Text('تم تحويل $done صفحة...'))],
          if (msg != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(msg!, style: const TextStyle(fontWeight: FontWeight.bold))),
        ]),
      );
}
