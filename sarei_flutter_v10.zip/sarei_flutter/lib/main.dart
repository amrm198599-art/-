import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'pdf_tools.dart';
import 'ocr_page.dart';
import 'sign_page.dart';
import 'pdf_images_page.dart';
import 'scanner_page.dart';
import 'status_page.dart';

void main() => runApp(const SareiApp());

const navy = Color(0xFF174B91);
const cyan = Color(0xFF37B8E8);
const orange = Color(0xFFFFA726);

class SareiApp extends StatefulWidget {
  const SareiApp({super.key});
  @override
  State<SareiApp> createState() => _SareiAppState();
}
class _SareiAppState extends State<SareiApp> {
  bool dark = false;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) { if (mounted) setState(() => dark = p.getBool('dark') ?? false); });
  }
  Future<void> _setDark(bool v) async {
    setState(() => dark = v);
    (await SharedPreferences.getInstance()).setBool('dark', v);
  }
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'سريع - Sarei',
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
    themeMode: dark ? ThemeMode.dark : ThemeMode.light,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: navy), scaffoldBackgroundColor: const Color(0xFFF3F7FC)),
    darkTheme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: cyan, brightness: Brightness.dark)),
    home: HomeScreen(dark: dark, onDarkChanged: _setDark),
  );
}

class ToolInfo {
  final String title, subtitle;
  final IconData icon;
  final Color color;
  final Widget Function() page;
  const ToolInfo(this.title, this.subtitle, this.icon, this.color, this.page);
}

class HomeScreen extends StatefulWidget {
  final bool dark;
  final ValueChanged<bool> onDarkChanged;
  const HomeScreen({super.key, required this.dark, required this.onDarkChanged});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int operations = 0;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() => operations = p.getInt('operations') ?? 0);
  }
  Future<void> _count() async {
    final p = await SharedPreferences.getInstance();
    operations++;
    await p.setInt('operations', operations);
    if (mounted) setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    final tools = <ToolInfo>[
      ToolInfo('تحويل صور إلى PDF', 'اجمع صورك في مستند', Icons.picture_as_pdf_rounded, const Color(0xFFE35B54), () => ImageToPdfPage(onDone: _count)),
      ToolInfo('إنشاء QR Code', 'للروابط والنصوص', Icons.qr_code_2_rounded, navy, () => const QrPage()),
      ToolInfo('واتساب مباشر', 'راسل رقمًا دون حفظه', Icons.chat_rounded, const Color(0xFF159B69), () => const WhatsAppPage()),
      ToolInfo('حافظة النصوص', 'احفظ النصوص ونظّفها', Icons.content_paste_rounded, const Color(0xFF8A62C7), () => ClipboardPage(onDone: _count)),
      ToolInfo('دمج PDF', 'اجمع عدة ملفات في ملف واحد', Icons.merge_type_rounded, const Color(0xFF2678C8), () => PdfToolPage(mode: PdfMode.merge, onDone: _count)),
      ToolInfo('ضغط PDF', 'تقليل حجم المستند', Icons.compress_rounded, const Color(0xFFE08A22), () => PdfToolPage(mode: PdfMode.compress, onDone: _count)),
      ToolInfo('PDF إلى صور', 'حفظ الصفحات كصور', Icons.photo_size_select_actual_rounded, const Color(0xFFC24B4B), () => PdfToImagesPage(onDone: _count)),
      ToolInfo('مسح المستندات', 'التقاط صورة للمستند', Icons.document_scanner_rounded, const Color(0xFF16866A), () => SmartScannerPage(onDone: _count)),
      ToolInfo('استخراج النص OCR', 'نص من صورة', Icons.text_snippet_rounded, const Color(0xFF6E55B7), () => OcrPage(onDone: _count)),
      ToolInfo('PDF إلى صور', 'حوّل الصفحات لصور', Icons.photo_size_select_large_rounded, const Color(0xFF287B9B), () => PdfToImagesPage(onDone: _count)),
      ToolInfo('حالات واتساب', 'حفظ الوسائط المتاحة', Icons.download_rounded, const Color(0xFF25965A), () => StatusSaverPage(onDone: _count)),
      ToolInfo('توقيع وتأمين PDF', 'توقيع وكلمة مرور', Icons.verified_user_rounded, navy, () => SignPage(onDone: _count)),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(mainAxisSize: MainAxisSize.min, children: [Text('سريع', style: TextStyle(fontWeight: FontWeight.w900)), SizedBox(width: 7), Icon(Icons.bolt_rounded, color: orange), SizedBox(width: 5), Text('Sarei', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))]),
        actions: [IconButton(tooltip: 'الإعدادات', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(dark: widget.dark, onDarkChanged: widget.onDarkChanged))), icon: const Icon(Icons.settings_outlined))],
      ),
      body: Directionality(textDirection: TextDirection.rtl, child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, cyan], begin: Alignment.topRight, end: Alignment.bottomLeft), borderRadius: BorderRadius.circular(24)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('أهلًا بك 👋', style: TextStyle(color: Colors.white70)),
              const SizedBox(height: 7),
              const Text('ما الأداة التي تحتاجها اليوم؟', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('كل أدوات ملفاتك وصورك.. في تطبيق واحد', style: TextStyle(color: Colors.white)),
              const SizedBox(height: 16),
              Row(children: [const Icon(Icons.check_circle_outline, color: Colors.white), const SizedBox(width: 7), Text('عدد العمليات المنجزة: $operations', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))])
            ]),
          ),
          const SizedBox(height: 22),
          const Text('الأدوات السريعة', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            itemCount: tools.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.08),
            itemBuilder: (context, i) {
              final t = tools[i];
              return Material(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(20),
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: t.page()))),
                  child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(width: 46, height: 46, decoration: BoxDecoration(color: t.color.withValues(alpha: .13), borderRadius: BorderRadius.circular(14)), child: Icon(t.icon, color: t.color, size: 27)),
                    const SizedBox(height: 12),
                    Text(t.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    const SizedBox(height: 4),
                    Text(t.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: Theme.of(context).colorScheme.onSurfaceVariant)),
                  ])),
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          Center(child: Text('معالجة محلية حيثما أمكن • سريع Sarei', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontSize: 12))),
        ],
      )),
    );
  }
}

class QrPage extends StatefulWidget { const QrPage({super.key}); @override State<QrPage> createState()=>_QrPageState(); }
class _QrPageState extends State<QrPage> {
  final controller = TextEditingController();
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('إنشاء QR Code')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const Text('اكتب رابطًا أو نصًا لتحويله إلى رمز QR.'), const SizedBox(height: 14),
    TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(labelText: 'الرابط أو النص', border: OutlineInputBorder(), hintText: 'https://example.com'), onChanged: (_) => setState((){})),
    const SizedBox(height: 22),
    if(controller.text.trim().isNotEmpty) Center(child: Container(color: Colors.white, padding: const EdgeInsets.all(16), child: QrImageView(data: controller.text.trim(), size: 220))),
    const SizedBox(height: 14),
    OutlinedButton.icon(onPressed: controller.text.trim().isEmpty ? null : () async { await Clipboard.setData(ClipboardData(text: controller.text.trim())); if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النص'))); }, icon: const Icon(Icons.copy), label: const Text('نسخ النص')),
  ]));
}

class WhatsAppPage extends StatefulWidget { const WhatsAppPage({super.key}); @override State<WhatsAppPage> createState()=>_WhatsAppPageState(); }
class _WhatsAppPageState extends State<WhatsAppPage> {
  final phone = TextEditingController();
  final message = TextEditingController();
  @override void dispose(){phone.dispose();message.dispose();super.dispose();}
  Future<void> openChat() async {
    final digits = phone.text.replaceAll(RegExp(r'[^0-9]'), '');
    if(digits.length < 8){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل رقمًا صحيحًا مع مفتاح الدولة')));return;}
    final uri = Uri.parse('https://wa.me/$digits${message.text.trim().isEmpty ? '' : '?text=${Uri.encodeComponent(message.text.trim())}'}');
    if(!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح واتساب أو المتصفح')));}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('واتساب مباشر')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const Icon(Icons.chat_rounded, size: 64, color: Color(0xFF159B69)), const SizedBox(height: 12),
    const Text('افتح محادثة دون حفظ الرقم في جهات الاتصال.', textAlign: TextAlign.center),
    const SizedBox(height: 24),
    TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'رقم الهاتف مع مفتاح الدولة', hintText: '201012345678', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
    const SizedBox(height: 14),
    TextField(controller: message, maxLines: 3, decoration: const InputDecoration(labelText: 'رسالة اختيارية', border: OutlineInputBorder())),
    const SizedBox(height: 20),
    FilledButton.icon(onPressed: openChat, icon: const Icon(Icons.open_in_new), label: const Text('فتح محادثة واتساب')),
    const SizedBox(height: 10),
    const Text('اكتب الرقم بصيغة دولية دون علامة + أو أصفار بادئة محلية. يتطلب إرسال الرسالة اتصالًا بالإنترنت.', style: TextStyle(fontSize: 12)),
  ]));
}

class ClipboardPage extends StatefulWidget { final Future<void> Function() onDone; const ClipboardPage({super.key, required this.onDone}); @override State<ClipboardPage> createState()=>_ClipboardPageState(); }
class _ClipboardPageState extends State<ClipboardPage> {
  final controller = TextEditingController();
  Future<void> paste() async { final d = await Clipboard.getData('text/plain'); if(d?.text != null) setState(()=>controller.text=d!.text!); }
  void clean() => setState(()=>controller.text=controller.text.replaceAll(RegExp(r'[ \t]+'), ' ').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim());
  @override void dispose(){controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('حافظة النصوص')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const Text('الصق النص أو اقرأ آخر نص نسخته، ثم نظّفه أو انسخه.'), const SizedBox(height: 14),
    TextField(controller: controller, maxLines: 9, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'اكتب النص هنا...')),
    const SizedBox(height: 12),
    Wrap(spacing: 8, runSpacing: 8, children: [
      OutlinedButton.icon(onPressed: paste, icon: const Icon(Icons.content_paste), label: const Text('لصق')),
      OutlinedButton.icon(onPressed: clean, icon: const Icon(Icons.cleaning_services), label: const Text('تنظيف النص')),
      FilledButton.icon(onPressed: () async {await Clipboard.setData(ClipboardData(text: controller.text)); await widget.onDone(); if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النص')));}, icon: const Icon(Icons.copy), label: const Text('نسخ النص')),
    ])
  ]));
}

class ImageToPdfPage extends StatefulWidget { final Future<void> Function() onDone; const ImageToPdfPage({super.key, required this.onDone}); @override State<ImageToPdfPage> createState()=>_ImageToPdfPageState(); }
class _ImageToPdfPageState extends State<ImageToPdfPage> {
  final List<XFile> images = [];
  bool busy = false;
  Future<void> pick() async { final picked = await ImagePicker().pickMultiImage(); if(picked.isNotEmpty) setState(()=>images.addAll(picked)); }
  Future<void> makePdf() async {
    if(images.isEmpty)return;
    setState(()=>busy=true);
    try {
      final doc = pw.Document();
      for(final image in images){ final bytes=await image.readAsBytes(); final img=pw.MemoryImage(bytes); doc.addPage(pw.Page(build: (_) => pw.Center(child: pw.Image(img, fit: pw.BoxFit.contain)))); }
      final bytes=await doc.save();
      await Printing.sharePdf(bytes: bytes, filename: 'sarei_images.pdf');
      await widget.onDone();
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء PDF: $e'))); }
    finally {if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('تحويل الصور إلى PDF')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const Text('اختر صورة أو أكثر، ثم أنشئ ملف PDF وشاركه أو احفظه من نافذة المشاركة.'), const SizedBox(height: 16),
    OutlinedButton.icon(onPressed: busy?null:pick, icon: const Icon(Icons.add_photo_alternate), label: const Text('اختيار الصور من الهاتف')),
    const SizedBox(height: 12), Text('عدد الصور المختارة: ${images.length}', style: const TextStyle(fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    if(images.isNotEmpty) SizedBox(height: 170, child: ListView(scrollDirection: Axis.horizontal, children: images.map((f)=>Padding(padding: const EdgeInsetsDirectional.only(end:8), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(f.path), width: 130, height: 170, fit: BoxFit.cover)))).toList())),
    const SizedBox(height: 22),
    FilledButton.icon(onPressed: images.isEmpty||busy?null:makePdf, icon: busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.picture_as_pdf), label: Text(busy?'جارٍ تجهيز الملف...':'إنشاء ومشاركة PDF')),
  ]));
}

class ScannerPage extends StatefulWidget { const ScannerPage({super.key}); @override State<ScannerPage> createState()=>_ScannerPageState(); }
class _ScannerPageState extends State<ScannerPage> {
  XFile? image;
  Future<void> take() async {final x=await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 90); if(x!=null)setState(()=>image=x);}
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('مسح المستندات')), body: ListView(padding: const EdgeInsets.all(20), children: [
    const Text('التقط صورة للمستند. هذه النسخة الأولية لا تتضمن قص الحواف التلقائي بعد.'),
    const SizedBox(height: 18),
    if(image!=null) ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(image!.path), fit: BoxFit.contain)),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: take, icon: const Icon(Icons.camera_alt), label: const Text('تصوير مستند')),
  ]));
}

class StatusHelpPage extends StatelessWidget {
  const StatusHelpPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('حالات واتساب')), body: Padding(padding: const EdgeInsets.all(22), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.download_for_offline_outlined, size: 70, color: Color(0xFF25965A)),
    const SizedBox(height: 18),
    const Text('حفظ الحالات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    const Text('في هذه النسخة الأولية لم يتم تفعيل اكتشاف حالات واتساب تلقائيًا. يمكن إضافة ذلك لاحقًا باستخدام منتقي الملفات وصلاحيات Android المناسبة.', textAlign: TextAlign.center),
  ])));
}

class ComingSoonPage extends StatelessWidget {
  final String title, description;
  const ComingSoonPage({super.key, required this.title, required this.description});
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: Text(title)), body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.construction_rounded, size: 64, color: navy),
    const SizedBox(height: 16),
    Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    Text(description, textAlign: TextAlign.center),
    const SizedBox(height: 18),
    const Chip(label: Text('قيد التطوير')),
  ]))));
}

class SettingsPage extends StatelessWidget {
  final bool dark; final ValueChanged<bool> onDarkChanged;
  const SettingsPage({super.key, required this.dark, required this.onDarkChanged});
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('الإعدادات')), body: ListView(children: [
    SwitchListTile(title: const Text('الوضع الليلي'), subtitle: const Text('تغيير مظهر التطبيق'), value: dark, onChanged: onDarkChanged, secondary: const Icon(Icons.dark_mode_outlined)),
    ListTile(leading: const Icon(Icons.email_outlined), title: const Text('الدعم الفني'), subtitle: const Text(supportEmail), onTap: () => launchUrl(Uri(scheme: 'mailto', path: supportEmail, queryParameters: {'subject': 'الدعم الفني - سريع Sarei'}))),
    ListTile(leading: const Icon(Icons.privacy_tip_outlined), title: const Text('سياسة الخصوصية'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrivacyPage()))),
    ListTile(leading: const Icon(Icons.share_outlined), title: const Text('مشاركة التطبيق'), onTap: () => Share.share('جرّب تطبيق سريع - Sarei: كل أدوات ملفاتك وصورك في تطبيق واحد.')),
    FutureBuilder<PackageInfo>(future: PackageInfo.fromPlatform(), builder: (c, snap) => ListTile(leading: const Icon(Icons.info_outline), title: const Text('سريع – Sarei'), subtitle: Text(snap.hasData ? 'الإصدار ${snap.data!.version} (${snap.data!.buildNumber})' : ''))),
  ]));
}

const supportEmail = 'waleedmmh789@gmail.com';

class PrivacyPage extends StatelessWidget {
  const PrivacyPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar: AppBar(title: const Text('سياسة الخصوصية')), body: const SingleChildScrollView(padding: EdgeInsets.all(20), child: SelectableText(privacyText, style: TextStyle(height: 1.8, fontSize: 15))));
}

const privacyText = '''سياسة الخصوصية - تطبيق سريع (Sarei)

يحترم تطبيق سريع خصوصيتك. تتم معالجة الملفات والصور والنصوص على جهازك فقط، ولا نرفعها إلى أي خادم (يحمّل التطبيق مرة واحدة ملف نموذج كل لغة تختارها (عربي أو إنجليزي) لاستخراج النص دون إرسال أي بيانات منك)، ولا نجمع بياناتك الشخصية ولا نبيعها ولا نشاركها مع أي طرف.

الصلاحيات:
- الكاميرا: لتصوير المستندات واستخراج النص منها، وتُستخدم فقط عند طلبك.
- الملفات والصور: يصل التطبيق إلى الملفات والمجلدات التي تختارها بنفسك عبر نافذة النظام فقط (للصور المكررة وتنظيف لقطات الشاشة وحفظ الحالات). لا يطلب صلاحية الوصول العام للصور، ولا يحذف شيئًا دون تأكيدك.

الاحتفاظ بالبيانات: لا نحتفظ بنسخ من ملفاتك. الملفات الناتجة تُحفظ أو تُشارك حسب اختيارك. يخزن التطبيق محليًا فقط عداد العمليات وإعداد الوضع الليلي.

أداة واتساب المباشر تفتح تطبيق واتساب أو المتصفح لرابط wa.me، وتخضع بعد ذلك لسياسة واتساب.

للتواصل والدعم الفني: waleedmmh789@gmail.com''';
