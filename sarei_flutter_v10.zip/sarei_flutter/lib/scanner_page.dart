import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart' as p;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

/// قص تقريبي للحواف (عتبة Otsu على الإضاءة) + تحسين الإضاءة والتباين.
Uint8List _process(List<dynamic> a) {
  var im = img.bakeOrientation(img.decodeImage(a[0] as Uint8List)!);
  final bw = a[1] as bool;
  if (im.width > 1800) im = img.copyResize(im, width: 1800);
  final t = img.copyResize(img.grayscale(im.clone()), width: 200);
  final hist = List<int>.filled(256, 0);
  for (final px in t) { hist[px.r.toInt().clamp(0, 255)]++; }
  final total = t.width * t.height;
  double sum = 0;
  for (var i = 0; i < 256; i++) { sum += i * hist[i]; }
  double sb = 0, best = 0; int wb = 0, th = 128;
  for (var i = 0; i < 256; i++) {
    wb += hist[i];
    if (wb == 0) continue;
    final wf = total - wb;
    if (wf == 0) break;
    sb += i * hist[i];
    final d = sb / wb - (sum - sb) / wf;
    final v = wb * wf * d * d;
    if (v > best) { best = v; th = i; }
  }
  int x0 = t.width, x1 = 0, y0 = t.height, y1 = 0;
  for (var y = 0; y < t.height; y++) {
    var c = 0;
    for (var x = 0; x < t.width; x++) { if (t.getPixel(x, y).r > th) c++; }
    if (c > t.width * 0.25) { if (y < y0) y0 = y; y1 = y; }
  }
  for (var x = 0; x < t.width; x++) {
    var c = 0;
    for (var y = 0; y < t.height; y++) { if (t.getPixel(x, y).r > th) c++; }
    if (c > t.height * 0.25) { if (x < x0) x0 = x; x1 = x; }
  }
  if (x1 > x0 && y1 > y0 && (x1 - x0) * (y1 - y0) > t.width * t.height * 0.3) {
    final s = im.width / t.width, m = 0.01 * im.width;
    final cx = (x0 * s - m).clamp(0, im.width - 1).toInt(), cy = (y0 * s - m).clamp(0, im.height - 1).toInt();
    final cw = ((x1 - x0 + 1) * s + 2 * m).clamp(1, im.width - cx).toInt(), ch = ((y1 - y0 + 1) * s + 2 * m).clamp(1, im.height - cy).toInt();
    im = img.copyCrop(im, x: cx, y: cy, width: cw, height: ch);
  }
  if (bw) im = img.grayscale(im);
  im = img.normalize(im, min: 0, max: 255);
  im = img.adjustColor(im, contrast: bw ? 1.35 : 1.15, brightness: 1.05);
  return Uint8List.fromList(img.encodeJpg(im, quality: 85));
}

class SmartScannerPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const SmartScannerPage({super.key, required this.onDone});
  @override
  State<SmartScannerPage> createState() => _SmartScannerPageState();
}

class _SmartScannerPageState extends State<SmartScannerPage> {
  final pages = <Uint8List>[];
  bool bw = true, busy = false;
  String? error;

  Future<void> capture(ImageSource s) async {
    final x = await ImagePicker().pickImage(source: s);
    if (x == null) return;
    setState(() { busy = true; error = null; });
    try {
      pages.add(await compute(_process, [await x.readAsBytes(), bw]));
    } catch (_) {
      error = 'تعذّرت معالجة الصورة.';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> makePdf() async {
    final doc = pw.Document();
    for (final b in pages) {
      doc.addPage(pw.Page(pageFormat: p.PdfPageFormat.a4, margin: pw.EdgeInsets.zero, build: (_) => pw.Center(child: pw.Image(pw.MemoryImage(b), fit: pw.BoxFit.contain))));
    }
    await Printing.sharePdf(bytes: await doc.save(), filename: 'sarei_scan.pdf');
    await widget.onDone();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('مسح المستندات')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          const Text('صوّر الورقة على خلفية مختلفة عنها. يقص التطبيق الحواف تقريبيًا ويحسّن الإضاءة. راجع النتيجة قبل المشاركة.'),
          const SizedBox(height: 12),
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: true, label: Text('أبيض وأسود')), ButtonSegment(value: false, label: Text('ملوّن'))],
            selected: {bw}, onSelectionChanged: busy ? null : (s) => setState(() => bw = s.first)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: busy ? null : () => capture(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('تصوير صفحة'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => capture(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('من المعرض'))),
          ]),
          if (busy) const Padding(padding: EdgeInsets.only(top: 16), child: LinearProgressIndicator()),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          const SizedBox(height: 16),
          for (var i = 0; i < pages.length; i++)
            Card(child: Column(children: [
              ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.memory(pages[i])),
              TextButton.icon(onPressed: () => setState(() => pages.removeAt(i)), icon: const Icon(Icons.delete_outline), label: Text('حذف الصفحة ${i + 1}')),
            ])),
          if (pages.isNotEmpty)
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE08A22), minimumSize: const Size.fromHeight(52)),
              onPressed: makePdf, icon: const Icon(Icons.picture_as_pdf), label: Text('إنشاء PDF (${pages.length} صفحة)')),
        ]),
      );
}
