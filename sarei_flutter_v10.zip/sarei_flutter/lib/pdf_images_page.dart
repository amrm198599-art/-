import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

class PdfToImagesPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const PdfToImagesPage({super.key, required this.onDone});
  @override
  State<PdfToImagesPage> createState() => _PdfToImagesPageState();
}

class _PdfToImagesPageState extends State<PdfToImagesPage> {
  String? name;
  List<File> files = [];
  bool busy = false;
  int done = 0;
  String? error;

  Future<void> run() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf'], withData: true);
    if (r == null || r.files.first.bytes == null) return;
    setState(() { name = r.files.first.name; busy = true; done = 0; files = []; error = null; });
    try {
      final dir = Directory('${(await getTemporaryDirectory()).path}/sarei_pages');
      if (await dir.exists()) await dir.delete(recursive: true);
      await dir.create(recursive: true);
      var n = 0;
      await for (final page in Printing.raster(r.files.first.bytes!, dpi: 150)) {
        final f = File('${dir.path}/page_${(++n).toString().padLeft(3, '0')}.png');
        await f.writeAsBytes(await page.toPng());
        files.add(f);
        if (mounted) setState(() => done = n);
      }
      if (n == 0) error = 'الملف لا يحتوي على صفحات.';
      else await widget.onDone();
    } catch (_) {
      error = 'تعذّر تحويل الملف. قد يكون محميًا بكلمة سر أو تالفًا.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('PDF إلى صور')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(60)),
            onPressed: busy ? null : run, icon: const Icon(Icons.upload_file), label: Text(name ?? 'اختر ملف PDF من الهاتف')),
          if (busy) ...[const SizedBox(height: 16), const LinearProgressIndicator(), const SizedBox(height: 8), Center(child: Text('تم تحويل $done صفحة...'))],
          if (error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          if (files.isNotEmpty && !busy) ...[
            const SizedBox(height: 16),
            for (final f in files) Padding(padding: const EdgeInsets.only(bottom: 10), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(f, cacheWidth: 700))),
            FilledButton.icon(
              onPressed: () => Share.shareXFiles([for (final f in files) XFile(f.path)]),
              icon: const Icon(Icons.share), label: Text('مشاركة أو حفظ ${files.length} صورة')),
            const Text('من نافذة المشاركة اختر "حفظ" أو أي تطبيق تريد.', style: TextStyle(fontSize: 12)),
          ],
        ]),
      );
}
