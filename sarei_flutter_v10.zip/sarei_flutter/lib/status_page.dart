import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:saf_stream/saf_stream.dart';
import 'package:saf_util/saf_util.dart';
import 'package:saf_util/saf_util_platform_interface.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _statusDoc =
    'content://com.android.externalstorage.documents/document/primary%3AAndroid%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses';

class StatusSaverPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const StatusSaverPage({super.key, required this.onDone});
  @override
  State<StatusSaverPage> createState() => _StatusSaverPageState();
}

class _StatusSaverPageState extends State<StatusSaverPage> {
  final _saf = SafUtil();
  final _stream = SafStream();
  List<SafDocumentFile> images = [], videos = [];
  bool busy = false, loaded = false;
  String? msg;

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final p = await SharedPreferences.getInstance();
    final uri = p.getString('status_dir');
    if (uri != null) await _load(uri);
  }

  Future<void> _pick() async {
    final d = await _saf.pickDirectory(writePermission: false, persistablePermission: true, initialUri: _statusDoc);
    if (d == null) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('status_dir', d.uri);
    await _load(d.uri);
  }

  Future<void> _load(String uri) async {
    setState(() { busy = true; msg = null; });
    try {
      final all = (await _saf.list(uri)).where((f) => !f.isDir).toList()
        ..sort((a, b) => b.lastModified.compareTo(a.lastModified));
      String ext(SafDocumentFile f) => f.name.split('.').last.toLowerCase();
      images = all.where((f) => ['jpg', 'jpeg', 'png', 'webp'].contains(ext(f))).toList();
      videos = all.where((f) => ['mp4', '3gp', 'mkv'].contains(ext(f))).toList();
      loaded = true;
      if (images.isEmpty && videos.isEmpty) msg = 'لا توجد حالات. شاهد بعض الحالات في واتساب ثم أعد المحاولة، وتأكد من اختيار المجلد الصحيح.';
    } catch (_) {
      msg = 'تعذّر قراءة المجلد. اختر مجلد .Statuses مرة أخرى.';
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _save(SafDocumentFile f, bool video) async {
    try {
      final base = f.name.contains('.') ? f.name.substring(0, f.name.lastIndexOf('.')) : f.name;
      if (video) {
        final tmp = '${(await getTemporaryDirectory()).path}/${f.name}';
        await _stream.copyToLocalFile(f.uri, tmp);
        await Gal.putVideo(tmp, album: 'Sarei');
        await File(tmp).delete();
      } else {
        await Gal.putImageBytes(await _stream.readFileBytes(f.uri), album: 'Sarei', name: 'sarei_$base');
      }
      await widget.onDone();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم الحفظ في المعرض')));
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذّر الحفظ')));
    }
  }

  Widget _grid(List<SafDocumentFile> list, bool video) => GridView.builder(
        padding: const EdgeInsets.all(12),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8),
        itemCount: list.length,
        itemBuilder: (c, i) {
          final f = list[i];
          return ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Stack(fit: StackFit.expand, children: [
              video
                  ? const ColoredBox(color: Colors.black26, child: Icon(Icons.play_circle_fill, size: 42))
                  : FutureBuilder<Uint8List>(
                      future: _stream.readFileBytes(f.uri),
                      builder: (c, s) => s.data == null ? const ColoredBox(color: Colors.black12) : Image.memory(s.data!, fit: BoxFit.cover, cacheWidth: 300)),
              PositionedDirectional(
                bottom: 4, end: 4,
                child: CircleAvatar(radius: 18, backgroundColor: Colors.black54,
                    child: IconButton(padding: EdgeInsets.zero, icon: const Icon(Icons.download, color: Colors.white, size: 20), onPressed: () => _save(f, video))),
              ),
            ]),
          );
        },
      );

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('حفظ حالات واتساب'),
            actions: [IconButton(onPressed: _pick, icon: const Icon(Icons.folder_open), tooltip: 'تغيير المجلد')],
            bottom: const TabBar(tabs: [Tab(text: 'الصور'), Tab(text: 'الفيديوهات')]),
          ),
          body: !loaded
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.folder_special_outlined, size: 64),
                  const SizedBox(height: 14),
                  const Text('اسمح للتطبيق بقراءة مجلد حالات واتساب مرة واحدة: اضغط "اختيار المجلد" ثم "استخدام هذا المجلد". يقرأ التطبيق هذا المجلد فقط ولا يرسل شيئًا خارج جهازك.', textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton.icon(onPressed: busy ? null : _pick, icon: const Icon(Icons.folder_open), label: const Text('اختيار المجلد')),
                  if (msg != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(msg!, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                ])))
              : msg != null && images.isEmpty && videos.isEmpty
                  ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(msg!, textAlign: TextAlign.center)))
                  : TabBarView(children: [_grid(images, false), _grid(videos, true)]),
        ),
      );
}
