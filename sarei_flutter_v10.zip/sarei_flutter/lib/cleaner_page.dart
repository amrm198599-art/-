import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:saf_stream/saf_stream.dart';
import 'package:saf_util/saf_util.dart';
import 'package:saf_util/saf_util_platform_interface.dart';
import 'pdf_tools.dart' show fmtSize;

// بدون صلاحيات وسائط: المستخدم يختار المجلد بنفسه عبر نافذة النظام (SAF).
const _shots = 'content://com.android.externalstorage.documents/document/primary%3APictures%2FScreenshots';
const _dcim = 'content://com.android.externalstorage.documents/document/primary%3ADCIM';
const _imgExt = ['jpg', 'jpeg', 'png', 'webp', 'heic'];

class _Item {
  final SafDocumentFile f;
  bool sel = false;
  _Item(this.f);
  int get bytes => f.length;
}

class _Thumb extends StatefulWidget {
  final SafStream stream;
  final String uri;
  const _Thumb(this.stream, this.uri);
  @override
  State<_Thumb> createState() => _ThumbState();
}

class _ThumbState extends State<_Thumb> {
  late final Future<Uint8List> f = widget.stream.readFileBytes(widget.uri);
  @override
  Widget build(BuildContext context) => FutureBuilder<Uint8List>(
      future: f,
      builder: (c, s) => s.data == null ? const ColoredBox(color: Colors.black12) : Image.memory(s.data!, fit: BoxFit.cover, cacheWidth: 250, gaplessPlayback: true));
}

/// duplicates=true: الصور المكررة داخل مجلد تختاره. false: لقطات الشاشة.
class CleanerPage extends StatefulWidget {
  final bool duplicates;
  final Future<void> Function() onDone;
  const CleanerPage({super.key, required this.duplicates, required this.onDone});
  @override
  State<CleanerPage> createState() => _CleanerPageState();
}

class _CleanerPageState extends State<CleanerPage> {
  final _saf = SafUtil();
  final _stream = SafStream();
  List<List<_Item>> groups = [];
  bool busy = false, scanned = false;
  int progress = 0;
  String? msg;

  List<_Item> get all => groups.expand((g) => g).toList();
  List<_Item> get selected => all.where((i) => i.sel).toList();

  bool _isImg(SafDocumentFile f) => !f.isDir && _imgExt.contains(f.name.split('.').last.toLowerCase());

  Future<void> _walk(String uri, List<SafDocumentFile> out, int depth) async {
    for (final f in await _saf.list(uri)) {
      if (out.length >= 3000) return;
      if (f.isDir) {
        if (depth < 2) await _walk(f.uri, out, depth + 1);
      } else if (_isImg(f)) {
        out.add(f);
      }
    }
  }

  Future<void> scan() async {
    final dir = await _saf.pickDirectory(writePermission: true, persistablePermission: false, initialUri: widget.duplicates ? _dcim : _shots);
    if (dir == null) return;
    setState(() { busy = true; msg = null; groups = []; progress = 0; });
    try {
      final files = <SafDocumentFile>[];
      await _walk(dir.uri, files, 0);
      if (widget.duplicates) {
        final bySize = <int, List<SafDocumentFile>>{};
        for (final f in files) { bySize.putIfAbsent(f.length, () => []).add(f); }
        for (final g in bySize.values.where((g) => g.length > 1)) {
          final byHash = <String, List<_Item>>{};
          for (final f in g) {
            final h = md5.convert(await _stream.readFileBytes(f.uri)).toString();
            byHash.putIfAbsent(h, () => []).add(_Item(f));
            if (++progress % 10 == 0 && mounted) setState(() {});
          }
          for (final grp in byHash.values.where((g) => g.length > 1)) {
            grp.sort((a, b) => a.f.lastModified.compareTo(b.f.lastModified));
            for (final i in grp.skip(1)) { i.sel = true; } // نُبقي الأقدم
            groups.add(grp);
          }
        }
      } else if (files.isNotEmpty) {
        groups = [(files.map(_Item.new).toList()..sort((a, b) => a.f.lastModified.compareTo(b.f.lastModified)))];
      }
      scanned = true;
    } catch (_) {
      msg = 'تعذّر قراءة المجلد. اختر مجلدًا آخر.';
    }
    if (mounted) setState(() => busy = false);
  }

  void selectOld() => setState(() {
        final lim = DateTime.now().subtract(const Duration(days: 30)).millisecondsSinceEpoch;
        for (final i in all) { i.sel = i.f.lastModified < lim; }
      });

  Future<void> delete() async {
    final sel = selected;
    final size = sel.fold<int>(0, (s, i) => s + i.bytes);
    final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
              title: const Text('حذف الصور'),
              content: Text('سيتم حذف ${sel.length} صورة (${fmtSize(size)}). لا يمكن التراجع بعد التأكيد.'),
              actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))],
            ));
    if (ok != true) return;
    final gone = <String>{};
    for (final i in sel) {
      try {
        await _saf.delete(i.f.uri, false);
        gone.add(i.f.uri);
      } catch (_) {}
    }
    setState(() {
      for (final g in groups) { g.removeWhere((i) => gone.contains(i.f.uri)); }
      groups.removeWhere((g) => g.length < (widget.duplicates ? 2 : 1));
    });
    if (gone.isNotEmpty) await widget.onDone();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(gone.isEmpty ? 'لم يتم حذف أي صورة' : 'تم حذف ${gone.length} صورة')));
  }

  @override
  Widget build(BuildContext context) {
    final sel = selected;
    return Scaffold(
      appBar: AppBar(title: Text(widget.duplicates ? 'الصور المكررة' : 'تنظيف لقطات الشاشة')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Text(widget.duplicates
                ? 'اختر مجلد الصور (مثل DCIM/Camera) وسيبحث التطبيق عن الصور المتطابقة تمامًا ويحدد الأحدث للحذف ويُبقي الأقدم. في نافذة النظام اضغط "استخدام هذا المجلد".'
                : 'اختر مجلد Pictures/Screenshots، ثم حدد اللقطات التي تريد حذفها. في نافذة النظام اضغط "استخدام هذا المجلد".'),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: busy ? null : scan, icon: const Icon(Icons.folder_open), label: Text(busy ? 'جارٍ الفحص... $progress' : 'اختيار المجلد وفحصه')),
            if (!widget.duplicates && groups.isNotEmpty) TextButton(onPressed: selectOld, child: const Text('تحديد الأقدم من 30 يومًا')),
            if (msg != null) Text(msg!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            if (scanned && !busy && groups.isEmpty && msg == null) const Padding(padding: EdgeInsets.only(top: 12), child: Text('لا توجد نتائج في هذا المجلد.')),
          ]),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            for (var gi = 0; gi < groups.length; gi++) ...[
              if (widget.duplicates) Padding(padding: const EdgeInsets.fromLTRB(4, 10, 4, 6), child: Text('مجموعة ${gi + 1} • ${fmtSize(groups[gi].first.bytes)} للنسخة', style: const TextStyle(fontWeight: FontWeight.bold))),
              Wrap(spacing: 6, runSpacing: 6, children: [
                for (final i in groups[gi])
                  GestureDetector(
                    onTap: () => setState(() => i.sel = !i.sel),
                    child: SizedBox(width: 100, height: 100, child: Stack(fit: StackFit.expand, children: [
                      ClipRRect(borderRadius: BorderRadius.circular(10), child: _Thumb(_stream, i.f.uri)),
                      if (i.sel) Container(decoration: BoxDecoration(color: Colors.black38, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.redAccent, width: 3))),
                      PositionedDirectional(top: 4, end: 4, child: Icon(i.sel ? Icons.check_circle : Icons.circle_outlined, color: Colors.white, size: 22)),
                    ])),
                  ),
              ]),
            ],
          ]),
        ),
        if (sel.isNotEmpty)
          SafeArea(child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700, minimumSize: const Size.fromHeight(52)),
              onPressed: delete, icon: const Icon(Icons.delete_outline),
              label: Text('حذف ${sel.length} صورة (${fmtSize(sel.fold<int>(0, (s, i) => s + i.bytes))})')),
          )),
      ]),
    );
  }
}
