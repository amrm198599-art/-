import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:image_picker/image_picker.dart';

/// يحمّل نموذج كل لغة مرة واحدة (نحو 1.5 إلى 4 MB) ثم يعمل OCR بدون إنترنت.
Future<void> _ensureModels(String lang) async {
  final dir = await FlutterTesseractOcr.getTessdataPath();
  await Directory(dir).create(recursive: true);
  for (final code in lang.split('+')) {
    final f = File('$dir/$code.traineddata');
    if (await f.exists() && await f.length() > 500000) continue;
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final url = 'https://github.com/tesseract-ocr/tessdata_fast/raw/main/$code.traineddata';
      final res = await (await client.getUrl(Uri.parse(url))).close();
      if (res.statusCode != 200) throw const HttpException('download');
      final bytes = await res.fold<List<int>>([], (a, b) => a..addAll(b));
      if (bytes.length < 500000) throw const HttpException('size');
      await f.writeAsBytes(bytes, flush: true);
    } finally {
      client.close();
    }
  }
}

class OcrPage extends StatefulWidget {
  final Future<void> Function() onDone;
  const OcrPage({super.key, required this.onDone});
  @override
  State<OcrPage> createState() => _OcrPageState();
}

class _OcrPageState extends State<OcrPage> {
  String lang = 'ara';
  String? imagePath, text, error;
  bool busy = false;

  Future<void> pick(ImageSource s) async {
    final x = await ImagePicker().pickImage(source: s);
    if (x == null) return;
    setState(() { imagePath = x.path; text = null; error = null; busy = true; });
    try {
      try {
        await _ensureModels(lang);
      } catch (_) {
        error = 'يلزم اتصال بالإنترنت مرة واحدة لتحميل نموذج اللغة، ثم يعمل بدونه.';
        if (mounted) setState(() => busy = false);
        return;
      }
      final r = await FlutterTesseractOcr.extractText(x.path,
          language: lang, args: {'psm': '4', 'preserve_interword_spaces': '1'});
      text = r.trim();
      if (text!.isEmpty) {
        error = 'لم يتم العثور على نص. جرّب صورة أوضح.';
      } else {
        await widget.onDone();
      }
    } catch (_) {
      error = 'تعذّر استخراج النص. حاول مرة أخرى بصورة أوضح.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('استخراج النص OCR')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'ara', label: Text('عربي')),
              ButtonSegment(value: 'eng', label: Text('English')),
              ButtonSegment(value: 'ara+eng', label: Text('الاثنان')),
            ],
            selected: {lang},
            onSelectionChanged: busy ? null : (s) => setState(() => lang = s.first),
          ),
          const SizedBox(height: 8),
          const Text('يُحمَّل نموذج كل لغة مرة واحدة عند أول استخدام، ثم يعمل بدون إنترنت. استخدم صورة واضحة ومضاءة جيدًا.', style: TextStyle(fontSize: 12)),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: FilledButton.icon(onPressed: busy ? null : () => pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('من المعرض'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => pick(ImageSource.camera), icon: const Icon(Icons.photo_camera), label: const Text('الكاميرا'))),
          ]),
          if (busy) const Padding(padding: EdgeInsets.only(top: 20), child: LinearProgressIndicator()),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 16), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
          if (text != null && text!.isNotEmpty) ...[
            const SizedBox(height: 16),
            Card(child: Padding(padding: const EdgeInsets.all(14), child: SelectableText(text!, style: const TextStyle(fontSize: 16, height: 1.6)))),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: text!));
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النص')));
              },
              icon: const Icon(Icons.copy), label: const Text('نسخ النص')),
          ],
        ]),
      );
}
